package com.example.bus_tracking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
